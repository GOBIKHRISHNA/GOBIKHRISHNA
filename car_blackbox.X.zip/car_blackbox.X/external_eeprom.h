#ifndef EXTERNAL_EEPROM_H
#define	EXTERNAL_EEPROM_H

#define  EEPROM_READ		0xA1
#define  EEPROM_WRITE		0xA0

void write_eeprom(unsigned char address1,  unsigned char data);//transmit the data from address  write means 0 read means 1
unsigned char read_eeprom(unsigned char address1); // write =0xA0 ,read = 0xA1


#endif