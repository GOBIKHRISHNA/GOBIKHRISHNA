#ifndef MAIN_H
#define MAIN_H

#define DASHBOARD_SCREEN 0
#define LOGIN_SCREEN 1
#define MENU_SCREEN 2
#define VIEW_LOG 3
#define DOWN_LOG 4
#define CLEAR_LOG 5
#define SET_TIME 6
#define RESET_PASSWORD 7

int sec;

int main_flag;

// password
unsigned int key_count;
int count;
unsigned int clear = 0;

// key pressing
unsigned char key;

// display menu
unsigned char key1;

unsigned int flag1;

// overflow
unsigned int over;

// time

// eeprom

// sdashboard show speed,timer,status for gear
void dashboard_screen(char key);
void login_screen(char key);
void display_menu(char key1);
static void get_time(void);
void display_time(void);
void init_timer0(void);

void view_log(char key1);
void Download_log(char key1);
void clear_log(void);
void set_time(char key1);

// menu_bar
void menu_bar(int flag);

// change password
void change_password(char key);

#endif
