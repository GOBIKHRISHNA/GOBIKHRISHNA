//dashboard_screen
#include <xc.h>
#include "main.h"
#include "matrix_keypad.h"
#include "clcd.h"
#include "adc.h"
#include "i2c.h"
#include "ds1307.h"
#include "external_eeprom.h"
#include "uart.h"

//time
unsigned char clock_reg[3];
// unsigned char calender_reg[4];
unsigned char time[9];
unsigned char date[11];

 unsigned int address = 10;

void dashboard_screen(char key)
{
    unsigned short adc;
    unsigned int speed;
    static int index = 0;

    char *str[] = {"ON", "GN", "GR", "G1", "G2", "G3", "G4", "G5", "C_"};

    clcd_print("TIMER  ", LINE1(0));

    clcd_print("EV  ", LINE1(9));
    clcd_print("SP", LINE1(14));
    // timer config
    get_time();
    display_time();

    
    // event status
    if (key == MK_SW1)
    {
        index = 8;
        if (index == 8)
        {
            clcd_print(str[8], LINE2(9));
        }
    }
    if (key == MK_SW2 && index <= 7)
    {
        index++;
    }
    else if (key == MK_SW3 && index > 1)
    {
        index--;
    }

    clcd_print(*(str + index), LINE2(9));
    
    
    

    // speed
    adc = read_adc(CHANNEL4);
    speed = adc / 10.3;
    clcd_putch((speed / 10) + 48, LINE2(14));
    clcd_putch((speed % 10) + 48, LINE2(15));


//eeprom
    if (key == MK_SW1 || key == MK_SW2 || key == MK_SW3) {
       
            write_eeprom(address++, time[0]);
            write_eeprom(address++, time[1]);
            write_eeprom(address++, time[2]);
            write_eeprom(address++, time[3]);
            write_eeprom(address++, time[4]);
            write_eeprom(address++, time[5]);
            write_eeprom(address++, time[6]);
            write_eeprom(address++, time[7]);

            write_eeprom(address++, str[index][0]);
            write_eeprom(address++, str[index][1]);

            write_eeprom(address++, (speed/10)+48);
            write_eeprom(address++, (speed%10)+48);
       

       
    }
    // sw5 press go to the log screen

    if (key == MK_SW5)
    {

        main_flag = LOGIN_SCREEN;
    }
}

void display_time(void)
{
    clcd_print(time, LINE2(0));
    

    // if (clock_reg[0] & 0x40)//12 hrs =>1-bit 0 to 3,2-bit 4
    // 						//24hrs =>2-bit 0 to 3,3-bit 4,5
    // {
    // 	if (clock_reg[0] & 0x20)
    // 	{
    // 		clcd_print("PM", LINE2(12));
    // 	}
    // 	else
    // 	{
    // 		clcd_print("AM", LINE2(12));
    // 	}s
    // }
}

static void get_time(void)
{
    clock_reg[0] = read_ds1307(HOUR_ADDR);
    clock_reg[1] = read_ds1307(MIN_ADDR);
    clock_reg[2] = read_ds1307(SEC_ADDR);

    if (clock_reg[0] & 0x40)
    {
        time[0] = '0' + ((clock_reg[0] >> 4) & 0x01);
        time[1] = '0' + (clock_reg[0] & 0x0F);
    }
    else
    {
        time[0] = '0' + ((clock_reg[0] >> 4) & 0x03);
        time[1] = '0' + (clock_reg[0] & 0x0F);
    }
    time[2] = ':';
    time[3] = '0' + ((clock_reg[1] >> 4) & 0x0F);
    time[4] = '0' + (clock_reg[1] & 0x0F);
    time[5] = ':';
    time[6] = '0' + ((clock_reg[2] >> 4) & 0x0F);
    time[7] = '0' + (clock_reg[2] & 0x0F);
    time[8] = '\0';
}
