#include <xc.h>
#include "main.h"
#include "matrix_keypad.h"
#include "clcd.h"
#include "adc.h"
#include "timer0.h"
#include "i2c.h"
#include "ds1307.h"
#include "external_eeprom.h"
#include "uart.h"

void init_config(void)
{

    /* Clear old content */
    PORTB = 0x00;

    /* Set PORTB as a Output */
    TRISB = 0x00;

    /* Enabling peripheral interrupt */
    PEIE = 1;

    /* Enabling global interrupt */
    GIE = 1;
    init_matrix_keypad();
    init_clcd();
    init_adc();
    init_i2c();
    init_ds1307();
    init_uart();
}

void main(void)
{
    static unsigned int i;
    main_flag = DASHBOARD_SCREEN;

    init_config();

    while (1)
    {

        key = read_switches(STATE_CHANGE);

        key1 = read_switches(LEVEL_CHANGE);

        switch (main_flag)
        {
        case DASHBOARD_SCREEN:
            dashboard_screen(key);
            break;
        case LOGIN_SCREEN:

            login_screen(key);
            break;
        case MENU_SCREEN:
            if (!flag1)
                display_menu(key1);
            else
                menu_bar(flag1);

            break;

        case VIEW_LOG:
            view_log(key1);
            break;
        case DOWN_LOG:
            Download_log(key1);
        break;
        case CLEAR_LOG:
            clear_log();
        break;
        case SET_TIME:
            set_time(key1);
        break;
        case RESET_PASSWORD:
            change_password(key);
            break;
        default:

            break;
        }
    }
}
