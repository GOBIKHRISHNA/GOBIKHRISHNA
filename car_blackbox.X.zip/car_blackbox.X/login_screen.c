// login_screen

#include <xc.h>
#include <string.h>
#include "main.h"
#include "matrix_keypad.h"
#include "clcd.h"
#include "external_eeprom.h"
#include "i2c.h"
#include "timer0.h"

unsigned char key;
unsigned int wait;
unsigned char k;
sec;
count;
int attempt = 3;
unsigned char str1[5];
unsigned int delay = 0;
int flag = 0;
unsigned char password[5] = "0000";

void login_screen(char key)
{
    if (attempt > 0)
    { // allow up to 5 attempts
        if (key_count < 4)
        { // collect 8 digit for password
            clcd_print(" Enter password ", LINE1(0));
            if (key_count == 0)
            {
                flag = 1; // clear the pervious line
            }
            if (flag == 1)
            {
                clcd_print("                ", LINE2(0));
                flag = 0;
            }
            if (delay++ == 1000)
            {
                clcd_putch('_', LINE2(count + 1));
            }
            else if (delay++ == 2000)
            {
                clcd_putch(' ', LINE2(count + 1));
                delay = 0;
            }
            if (key == MK_SW5)
            {
                str1[key_count++] = '0';

                clcd_putch('*', LINE2(count++));
            }
            if (key == MK_SW6)
            {
                str1[key_count++] = '1';
                clcd_putch('*', LINE2(count++));
            }
        }
        else
        {
            str1[4] = '\0';
            // for (int k = 0; k < 4; k++)
            // {
            //     str[k] = read_eeprom(k);
            // }
            password[0] = read_eeprom(0);
            password[1] = read_eeprom(1);
            password[2] = read_eeprom(2);
            password[3] = read_eeprom(3);
            password[4] = '\0';

            if (strcmp(password, str1) == 0)
            {

                clcd_print("Correct password", LINE1(0));
                clcd_print("                ", LINE2(0));
                attempt =3;
                
                if (wait++ == 100)
                {

                    main_flag = MENU_SCREEN;

                    wait = 0;
                }
            }
            else
            {
                clcd_print("               ", LINE1(0));
                 clcd_print(password, LINE1(0));
                 clcd_print(str1, LINE1(5));

                 //clcd_print(" Wrong password ", LINE1(1));
                clcd_putch('0' + attempt - 1, LINE2(0));
                clcd_print(" attempts left ", LINE2(1));

                if (wait++ == 1000)
                {
                    clcd_print("                ", LINE2(0));
                    attempt--;
                    key_count = 0;
                    count = 0;
                    wait = 0;
                }
            }
        }
    }
    else
    {
        clcd_print(" User is blocked ", LINE1(0));
        clcd_print("wait for  sec", LINE2(0));

        clcd_putch((sec / 10) + 48, LINE2(9));
        clcd_putch((sec % 10) + 48, LINE2(10));

        if (sec == 0)
        {
            attempt = 0;
            CLEAR_DISP_SCREEN;
            sec = 60;
            TMR0ON = 0;
        }
    }
}