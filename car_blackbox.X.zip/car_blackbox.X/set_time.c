#include <xc.h>
#include "main.h"
#include "matrix_keypad.h"
#include "clcd.h"
#include "adc.h"
#include "i2c.h"
#include "ds1307.h"
#include "external_eeprom.h"
#include "uart.h"


int field;

unsigned char clock[3];
unsigned char clock[3];
int key_count2 =0, key_count1 = 0, blink, blink_counter;
unsigned char time[9];

static void get_time(void) {

//    clock[0] = read_ds1307(HOUR_ADDR);
//    clock[1] = read_ds1307(MIN_ADDR);
//    clock[2] = read_ds1307(SEC_ADDR);

    if (clock[0] & 0x40) {
        time[0] = '0' + ((clock[0] >> 4) & 0x01);
        time[1] = '0' + (clock[0] & 0x0F);
    } else {
        time[0] = '0' + ((clock[0] >> 4) & 0x03);
        time[1] = '0' + (clock[0] & 0x0F);
    }
    time[2] = ':';
    time[3] = '0' + ((clock[1] >> 4) & 0x0F);
    time[4] = '0' + (clock[1] & 0x0F);
    time[5] = ':';
    time[6] = '0' + ((clock[2] >> 4) & 0x0F);
    time[7] = '0' + (clock[2] & 0x0F);
    time[8] = '\0';
}

unsigned char bin_to_bcd(unsigned char bin) {
    return ((bin / 10) << 4) | (bin % 10);
}

unsigned char bcd_to_bin(unsigned char bcd) {
    return ((bcd >> 4) * 10) + (bcd & 0x0F);
}

void set_time(char key1)
 {


    clock[0] = read_ds1307(HOUR_ADDR);
    clock[1] = read_ds1307(MIN_ADDR);
    clock[2] = read_ds1307(SEC_ADDR);

    unsigned char min;
    unsigned char hour;
    unsigned char sec;

    
    clcd_print("   set time        ", LINE1(0));

    blink_counter++;
    if (blink_counter > 300) {
        blink_counter = 0;
        blink = !blink;
    }

    get_time();

    if (field == 0 && blink) {
        time[0] = ' ';
        time[1] = ' ';
    } else if (field == 1 && blink) {
        time[3] = ' ';
        time[4] = ' ';
    } else if (field == 2 && blink) {
        time[6] = ' ';
        time[7] = ' ';
    }
    display_time();
    if (key1 == MK_SW6) {
        key_count1++;
        if (key_count1 > 1000) {
            key_count1 = 0;
            write_ds1307(HOUR_ADDR, clock[0]);
            write_ds1307(MIN_ADDR, clock[1]);
            write_ds1307(SEC_ADDR, clock[2]);
            clcd_print("                ", LINE1(0));
            clcd_print("                ", LINE2(0));
            flag1=0;
            main_flag = DASHBOARD_SCREEN;
        }
    } else if (key_count1 > 0 && key_count1 < 1000 && key1 == ALL_RELEASED) {
        key_count1 = 0;
        field = (field + 1) % 3; // Cycle through hours, minutes, and seconds
    } else {
        key_count1 = 0;
    }

    if (key1 == MK_SW5) {
        key_count2++;
        if (key_count2 > 500) {
            key_count2 = 0;
             flag1 = 0;
            clcd_print("                ", LINE1(0));
            clcd_print("                ", LINE2(0));
            main_flag = DASHBOARD_SCREEN;
        }
    } else if (key_count2 > 0 && key_count2 < 500 && key1 == ALL_RELEASED) {
        key_count2 = 0;

        if (field == 0) {
            hour = bcd_to_bin(clock[0]);
            hour++;
            if (hour > 23) {
                hour = 0;
            }
        }
        if (field == 1) {
            min = bcd_to_bin(clock[1]);
            min++;
            if (min > 59) {
                min = 0;
            }
        }
        if (field == 2) { // Adjust seconds
            sec = bcd_to_bin(clock[2]);
            sec++;
            if (sec > 59) {
                sec = 0;
            }
        }
    }
    clock[0] = bin_to_bcd(hour);
    clock[1] = bin_to_bcd(min);
    clock[2] = bin_to_bcd(sec);


  

}