/*
 * File:   viewlog.c
 * Author: gm956
 *
 * Created on 9 October, 2024, 4:36 PM
*/