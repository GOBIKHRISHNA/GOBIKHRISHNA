// display_menu

#include <xc.h>
#include "main.h"
#include "matrix_keypad.h"
#include "clcd.h"
#include "adc.h"
#include "i2c.h"
#include "ds1307.h"
#include "external_eeprom.h"
#include "uart.h"


#define MAX_VALUE 1000 // long press

unsigned int count4 = 0;
unsigned int index = 0;
unsigned int long_press = 0;
unsigned int long_press1 = 0;
unsigned int wait = 0;

// time
unsigned char clock_reg[3];
// unsigned char calender_reg[4];
unsigned char time[9];

void display_menu(char key1)
{
    char *str1[] = {"View Log         ", "Download Log           ", "Clear Log           ", "Set time           ", "Change Password         "};

    if (index == 0)
    {
        clcd_print("->", LINE1(0));
        clcd_print("  ", LINE2(0));
    }
    else
    {
        clcd_print("  ", LINE1(0));
        clcd_print("->", LINE2(0));
    }

    clcd_print(str1[count4], LINE1(2));
    clcd_print(str1[count4 + 1], LINE2(2));

    if (key1 == MK_SW5)
    {
        long_press++;
        if (long_press > MAX_VALUE) // long_press
        {
            // menu bar
            CLEAR_DISP_SCREEN;
            flag1 = count4 + index + 1; //
        }
    }
    else if (long_press < MAX_VALUE && long_press > 0 && key1 == ALL_RELEASED)
    {

        // Increment the count (action on short press)
        if (count4 > 0)
        {
            if (index == 1)
            {
                index = 0;
            }
            else
            {
                count4--;
            }
        }
        else
        {
            count4 = 0;
        }

        long_press = 0; // Reset the counter after handling the short press
    }
    else
    {
        long_press = 0; // Reset count_key if no press or long enough press is detected
    }

    // switch 6
    if (key1 == MK_SW6)
    {
        long_press1++;
        if (long_press1 > MAX_VALUE)
        {
            // menu bar
            CLEAR_DISP_SCREEN;
            main_flag = DASHBOARD_SCREEN;
            key_count = 0;
            long_press1 = 0;
            index = 0;
            count = 0;

            // flag1 = (count + index); /* Log out operation */
        }
    }
    else if (long_press1 < MAX_VALUE && long_press1 > 0 && key1 == ALL_RELEASED)
    {

        // Increment the count (action on short press)
        if (count4 < 3)
        {
            if (index == 0)
            {
                index = 1;
            }
            else
            {
                count4++;
            }
        }
        long_press1 = 0; // Reset the counter after handling the short press
    }
    else
    {
        long_press1 = 0; // Reset count_key if no press or long enough press is detected
    }
}

// Display the current menu bar

void select_menu()
{
    clcd_print("SELECT_MENU        ", LINE1(0));
    clcd_print("                   ", LINE2(0));
}

void logout()
{
}

void menu_bar(int flag1)
{

    switch (flag1)
    {
    case 1:
        // viewlog

        if (wait++ == 100)
        {
            clcd_print("                    ", LINE1(0));
            main_flag = VIEW_LOG;
            wait = 0;
        }
        clcd_print("                     ", LINE1(0));

        break;
    case 2:
        // Downloadlog
        // clcd_print("Downloadlog      ", LINE1(0));
        main_flag = DOWN_LOG;
        break;
    case 3:
        // clear log
        // clcd_print("clearlog        ", LINE1(0));
        main_flag = CLEAR_LOG;
        break;
    case 4:
        // set time
        main_flag = SET_TIME;
        set_time(key1);
        break;
    case 5:
        // change password

        main_flag = RESET_PASSWORD;
        break;
    case 6:
        clcd_print("                  ", LINE1(0));
        dashboard_screen(key);
        break;
    }
}

void change_password(char key)
{

    unsigned char st1[5];
    unsigned char st2[5];
    unsigned char ch[5];
    static int key_count0 = 0;
    static int key_count1 = 0;
    static unsigned int count1 = 0;
    static unsigned int count2 = 0;

    static int flag = 0;
    static unsigned int delay = 0;
    unsigned char key2;

    if (key_count0 < 4)
    { // collect 8 digit for password
        clcd_print(" Enter password ", LINE1(0));
        if (key_count0 == 0)
        {
            flag = 1; // clear the pervious line
        }
        if (flag == 1)
        {
            clcd_print("                ", LINE2(0));
            flag = 0;
        }
        if (delay++ == 1000)
        {
            clcd_putch('_', LINE2(count1 + 1));
        }
        else if (delay++ == 2000)
        {
            clcd_putch(' ', LINE2(count1 + 1));
            delay = 0;
        }
        if (key == MK_SW5)
        {
            st1[key_count0++] = '0';

            clcd_putch('*', LINE2(count1++));
        }
        if (key == MK_SW6)
        {
            st1[key_count0++] = '1';
            clcd_putch('*', LINE2(count1++));
        }
    }

    else if (key_count1 < 4)
    {

        // re Enter password

        clcd_print(" Re Enter password ", LINE1(0));
        if (key_count1 == 0)
        {
            flag = 1; // clear the pervious line
        }
        if (flag == 1)
        {
            clcd_print("                ", LINE2(0));
            flag = 0;
        }
        if (delay++ <= 1000)
        {
            clcd_putch('_', LINE2(count2 + 1));
        }
        else if (delay++ <= 2000)
        {
            clcd_putch(' ', LINE2(count2 + 1));
            delay = 0;
        }
        if (key == MK_SW5)
        {
            st2[key_count1++] = '0';

            clcd_putch('*', LINE2(count2++));
        }
        if (key == MK_SW6)
        {

            st2[key_count1++] = '1';
            clcd_putch('*', LINE2(count2++));
        }
    }
    else
    {
        st1[4] = '\0';
        st2[4] = '\0';
        if (strcmp(st2, st1) == 0)
        {
            write_eeprom(0, st2[0]);
            write_eeprom(1, st2[1]);
            write_eeprom(2, st2[2]);
            write_eeprom(3, st2[3]);

            // clcd_print(st1,LINE1(0));
            clcd_print("password changed", LINE1(0));
            clcd_print(" successfully  ", LINE2(0));

            if (wait++ == 100)
            {
                clcd_print("                   ", LINE1(0));
                clcd_print("                   ", LINE2(0));
                key_count = 0;
                count = 0;
                wait = 0;
                flag1 = 0;
                main_flag = DASHBOARD_SCREEN;
            }
        }
        else
        {

            clcd_print("incorrect password   ", LINE1(0));
            clcd_print(" Try Again  ", LINE2(0));
            key_count = 0;
            count = 0;
            wait = 0;
            flag1 = 1;
            main_flag = MENU_SCREEN;
        }
    }
}

// view log
unsigned int sp;
unsigned char bytes[25];
unsigned short adc;

unsigned char tim[13];

int index1 = 0;
unsigned int addr = 10;
void view_log(char key1)
{

    

    static unsigned int longpress = 0;
    static unsigned int longpress1 = 0;
    clcd_print("#Viewlog        ", LINE1(0));

    for (int t = 0; t < 12; t++)
    {

        tim[t] = read_eeprom(addr++);
    }
    tim[12] = '\0';
    clcd_print(tim, LINE2(0));

    addr = addr - 12;

    if (key1 == MK_SW5)
    {
        // clcd_print("hi", LINE2(12));
        longpress1++;
        if (longpress1 > 500) // long_press
        {
            // menu bar
            // long_press1 = 0;
            // clcd_print("               ", LINE1(0));
            // clcd_print("               ", LINE2(0));
        }
    }
    else if (longpress1 < 500 && longpress1 > 0 && key1 == ALL_RELEASED)
    {

       

        if (addr > 10)
        {
            addr = addr - 12;
        }
         longpress1 = 0;
    }
    else
    {
        longpress1 = 0;
    }

    // sw6
    if (key1 == MK_SW6)
    {
        longpress++;
        if (longpress > 500) // long_press
        {
            longpress = 0;
            flag1 = 0;
            key_count = 0;
            count = 0;
            main_flag = MENU_SCREEN;
        }
    }
    else if (longpress < 500 && longpress > 0 && key1 == ALL_RELEASED)
    {
        

        if (addr < 120)
        {
            addr = addr + 12;
        }
        long_press = 0;
    }
    else
    {
        longpress = 0;
    }
    
}

void Download_log(char key1)
{
    unsigned int addr = 10; // Start of log storage
    unsigned char data[12];
    static unsigned int longcount = 0;

    for (int i = 0; i < 12; i++)
    {
        data[i] = read_eeprom(addr++);
        // Send log data via UART
    }
    data[12] = '\0';
    addr -= 12;

    puts("captured_event");
    puts(data);
    putch('\n');
    putch('\r');
    for (wait = 80000; wait--;)
        ;
    CLEAR_DISP_SCREEN;
    flag1 = 0;
    key_count = 0;
    main_flag = MENU_SCREEN;
}

void clear_log(void)
{
    
    for(int i=10;i<=255;i++){
        write_eeprom(i,0);
    }
    
    clcd_print("CLEAR LOG", LINE1(0));
    clcd_print("SUCCESSFUL", LINE2(0));
    for (wait = 100000; wait--;)
        ;
    CLEAR_DISP_SCREEN;

    flag1 = 1;
    key_count = 0;
    main_flag = MENU_SCREEN;
}
