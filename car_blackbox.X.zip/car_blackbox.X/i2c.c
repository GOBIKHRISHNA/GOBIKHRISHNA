
#include "main.h"
#include "ds1307.h"
#include "i2c.h"
#include <xc.h>


void init_i2c(void)
{
	/* Set SCL and SDA pins as inputs */
	TRISC3 = 1;
	TRISC4 = 1;
	/* Set I2C master mode */
	SSPCON1 = 0x28;

	SSPADD = 0x31;
	/* Use I2C levels, worked also with '0' */
	CKE = 0;
	/* Disable slew rate control  worked also with '0' */
	SMP = 1;
	/* Clear SSPIF interrupt flag */
	SSPIF = 0;
	/* Clear bus collision flag */
	BCLIF = 0;
}

//check the instruction is completed or not 
void i2c_idle(void)
{
	while (!SSPIF);
	// 0  instruction is not completed
	// 1  instruction is completed
	SSPIF = 0;
}

void i2c_ack(void)//we are not use ack function 
{
	if (ACKSTAT)
	{
		/* Do debug print here if required */
	}
}


//Use to start a communication 
void i2c_start(void)
{
	SEN = 1;//start condition
	i2c_idle();
}

//stop a communication 
void i2c_stop(void)
{
	PEN = 1;//stop condition 
	i2c_idle();
}

//to initiate repeat start
void i2c_rep_start(void)
{
	RSEN = 1;//Enable recive mode
	i2c_idle();
}

//to transmit the data 
void i2c_write(unsigned char data)
{
	SSPBUF = data;//serial Receiver/Transmit Buffer rag
	i2c_idle();
}

//to put the master to receive mode 
void i2c_rx_mode(void)
{
	RCEN = 1;//to enable a recive mode
	i2c_idle();
}

void i2c_no_ack(void)
{
	ACKDT = 1;//no ACK 
	ACKEN = 1;//To use the data enable a bit 
}


//to receive the data 
unsigned char i2c_read(void)//microcontroller will read the data from slave 
{
	i2c_rx_mode();
	i2c_no_ack();

	return SSPBUF;
}